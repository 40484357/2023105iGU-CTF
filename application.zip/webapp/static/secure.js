function checkPassword(username, password)
{
  if( username === 'admin' && password === 'IloveWickedGames2023' )
  {
    return true;
  }
  else
  {
    return false;
  }
}
